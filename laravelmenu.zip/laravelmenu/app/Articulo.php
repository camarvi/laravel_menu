<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Articulo extends Model
{
    //
    protected $filltable = ['nombre','pais','categoria','precio'];
}
