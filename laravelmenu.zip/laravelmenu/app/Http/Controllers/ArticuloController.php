<?php

namespace App\Http\Controllers;

use App\Articulo;
use Illuminate\Http\Request;

class ArticuloController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    // LISTADO ARTICULOS

    public function listado(){

        //Flight::where('destination', 'Zurich')->cursor()
        // ->orderBy('name')

        //$data['users']

        //$articulos = Articulo::orderBy('nombre')->get();
        //echo $articulos;
        
        $data['articulos'] = Articulo::orderBy('nombre')->get();

        return view("articulo.listado", $data);

    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function save(Request $request)
    {
        //
        $validator = $this->validate($request,[
            'nombre'=>'required|string|max:100',
            'pais' => 'required|string|max:100',
            'categoria' => 'required|string|max:100',
            'precio'=> 'required'
        ]);

        $datos_articulo = request()->except('_token');

        Articulo::insert($datos_articulo);

        return back()->with('usuarioGuardado','Articulo guardado');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Articulo  $articulo
     * @return \Illuminate\Http\Response
     */
    public function show(Articulo $articulo)
    {
        //
    }

   
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Articulo  $articulo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Articulo $articulo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Articulo  $articulo
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        Articulo::destroy($id);

        return back()->with('articuloEliminado','Articulo Elinminado');
    }


    public function editform($id){
        
        //Busco el articulo
        $articulo = Articulo::findOrFail($id);
        //Lo paso a la vista
        return view("articulo.editform", compact('articulo'));

    }

    public function edit(Request $request, $id){
        $datoArticulo = request()->except((['_token','_method']));
        Articulo::where('id','=',$id)->update($datoArticulo);

        return back()->with('articuloModificado','Articulo Modificado');
      
    }

}
