
@extends("layouts.plantilla")

@section("cuerpo")


<div class="container mt-2">

<!--Mensaje flash -->

@if (session('articuloModificado'))
    <div class="alert alert-success">
        {{ session('articuloModificado') }}
    </div>
@endif


<!-- Validacion de errores -->
@if($errors->any())
    <div class="alert alert-danger">
        <ul>
             @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<!-- Fin Mostrar mensajes de error -->

</div>



<form action="{{ route('edit', $articulo->id) }}" method="POST">
   @csrf @method('PATCH')
  <div class="form-group">
    <label>Nombre</label>
    <input type="text" class="form-control" name="nombre" value="{{ $articulo->nombre }}">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Pais</label>
    <input type="text" class="form-control" name="pais" value="{{ $articulo->pais }}">
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Categoria</label>
    <input type="text" class="form-control" name="categoria" value="{{ $articulo->categoria }}">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Precio</label>
    <input type="text" class="form-control" name="precio" value="{{ $articulo->precio }}">
  </div>
  
  <button type="submit" class="btn btn-primary">Modificar</button>
  <a href="{{ route('listado') }}" class="btn btn-danger">Volver Atras</a>

</form>



@endsection