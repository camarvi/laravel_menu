
@extends("layouts.plantilla")

@section("cuerpo")


<!--Mensaje flash -->

@if (session('usuarioGuardado'))
    <div class="alert alert-success">
        {{ session('usuarioGuardado') }}
    </div>
@endif


<!-- Validacion de errores -->
@if($errors->any())
    <div class="alert alert-danger">
        <ul>
             @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<!-- Fin Mostrar mensajes de error -->

<form action="{{ route('save') }}" method="POST">
     @csrf
  <div class="form-group">
    <label>Nombre</label>
    <input type="text" class="form-control" name="nombre" value="{{ old('nombre') }}">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Pais</label>
    <input type="text" class="form-control" name="pais" value="{{ old('pais') }}">
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Categoria</label>
    <input type="text" class="form-control" name="categoria" value="{{ old('categoria') }}">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Precio</label>
    <input type="text" class="form-control" name="precio" value="{{ old('precio') }}">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

@endsection