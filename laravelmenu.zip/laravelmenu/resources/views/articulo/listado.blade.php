
@extends("layouts.plantilla")

@section("cuerpo")

   <!--Mensaje flash -->
   @if (session('articuloEliminado'))
        <div class="alert alert-success">
            {{ session('articuloEliminado') }}
        </div>

    @endif

     <!-- Fin Mensaje Flash -->




<div class="container mt-5">


<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">Pais</th>
      <th scope="col">Categoria</th>
      <th scope="col">Precio</th>
      <th scope="col">Borrar</th>
    </tr>
  </thead>
  <tbody>
  @foreach ($articulos as $articulo)
    <tr>
      <th scope="row">{{ $articulo->id }}</th>
      <td>{{ $articulo->nombre }}</td>
      <td>{{ $articulo->pais }}</td>
      <td>{{ $articulo->categoria }}</td>
      <td>{{ $articulo->precio}}</td>
      <td>
        <a href="{{ route('editform' , $articulo->id) }}" class="btn btn-primary">
           Editar
        </a>
            <form action="{{ route('delete', $articulo->id) }}" method="POST">
            @csrf @method('DELETE')
                      
                <button class="btn btn-danger" onclick="return confirm('¿Eliminar definitivamente?');">Eliminar
                </button>

            </form>

      </td>
    </tr>
   @endforeach
  </tbody>
</table>


</div>
@endsection