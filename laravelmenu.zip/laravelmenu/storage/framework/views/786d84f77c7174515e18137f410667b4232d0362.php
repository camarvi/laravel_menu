


<?php $__env->startSection("cuerpo"); ?>


<!--Mensaje flash -->

<?php if(session('usuarioGuardado')): ?>
    <div class="alert alert-success">
        <?php echo e(session('usuarioGuardado')); ?>

    </div>
<?php endif; ?>


<!-- Validacion de errores -->
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<!-- Fin Mostrar mensajes de error -->

<form action="<?php echo e(route('save')); ?>" method="POST">
     <?php echo csrf_field(); ?>
  <div class="form-group">
    <label>Nombre</label>
    <input type="text" class="form-control" name="nombre" value="<?php echo e(old('nombre')); ?>">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Pais</label>
    <input type="text" class="form-control" name="pais" value="<?php echo e(old('pais')); ?>">
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Categoria</label>
    <input type="text" class="form-control" name="categoria" value="<?php echo e(old('categoria')); ?>">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Precio</label>
    <input type="text" class="form-control" name="precio" value="<?php echo e(old('precio')); ?>">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravelmenu\resources\views/articulo/articuloform.blade.php ENDPATH**/ ?>