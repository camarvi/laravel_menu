


<?php $__env->startSection("cuerpo"); ?>

   <!--Mensaje flash -->
   <?php if(session('articuloEliminado')): ?>
        <div class="alert alert-success">
            <?php echo e(session('articuloEliminado')); ?>

        </div>

    <?php endif; ?>

     <!-- Fin Mensaje Flash -->




<div class="container mt-5">


<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">Pais</th>
      <th scope="col">Categoria</th>
      <th scope="col">Precio</th>
      <th scope="col">Borrar</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($articulo->id); ?></th>
      <td><?php echo e($articulo->nombre); ?></td>
      <td><?php echo e($articulo->pais); ?></td>
      <td><?php echo e($articulo->categoria); ?></td>
      <td><?php echo e($articulo->precio); ?></td>
      <td>
        <a href="<?php echo e(route('editform' , $articulo->id)); ?>" class="btn btn-primary">
           Editar
        </a>
            <form action="<?php echo e(route('delete', $articulo->id)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      
                <button class="btn btn-danger" onclick="return confirm('¿Eliminar definitivamente?');">Eliminar
                </button>

            </form>

      </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravelmenu\resources\views/articulo/listado.blade.php ENDPATH**/ ?>