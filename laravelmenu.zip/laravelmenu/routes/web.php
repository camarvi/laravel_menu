<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
Route::get('/', function () {
    return view('articulo.listado');
})->name('listado');
*/

Route::get('/', "ArticuloController@listado")->name('listado');



Route::get("/nuevo", function(){

    return view('articulo.articuloform');

})->name('nuevo');

Route::post("/save","ArticuloController@save")->name('save');

Route::delete("/delete/{id}", "ArticuloController@delete")->name('delete');

//Formulario para editar
Route::get("/editform/{id}", "ArticuloController@editform")->name('editform');

//modificar registro en la BD
Route::patch("/edit/{id}", "ArticuloController@edit")->name('edit');
